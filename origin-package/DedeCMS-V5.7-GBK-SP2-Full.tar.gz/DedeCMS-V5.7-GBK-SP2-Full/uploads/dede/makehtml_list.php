<?php
/**
 * �����б���Ŀ
 *
 * @version        $Id: makehtml_list.php 1 11:09 2010��7��19��Z tianya $
 * @package        DedeCMS.Administrator
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__)."/config.php");
require_once(DEDEINC."/typelink.class.php");
include DedeInclude('templets/makehtml_list.htm');